Arquivo zip gerado em: 21/08/2021 19:58:47 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Exercício 0.0]  Revisando Vetores  e Funções