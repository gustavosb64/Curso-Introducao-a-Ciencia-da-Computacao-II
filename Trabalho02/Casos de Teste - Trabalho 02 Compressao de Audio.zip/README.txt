Arquivo zip gerado em: 18/10/2021 11:43:35 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho 02: Compressão de Áudio