Arquivo zip gerado em: 25/11/2021 13:59:03 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Exercício 3] Busca Indexada em Lista Encadeada